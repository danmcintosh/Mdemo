sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function (DateFormat) {
	"use strict";

	return {
		/**
		 * Date formatter
		 */
		formatDate: function (aDate) {
			if (aDate) {
				var oDateFormat = DateFormat.getDateTimeInstance({
						pattern: "dd-MMM-YYYY"
							// pattern: "MM/dd/YYYY"
					}),
					// timezoneOffset is in hours convert to milliseconds
					tzOffsetMs = aDate.getTimezoneOffset() * 60 * 1000;
				return oDateFormat.format(new Date(aDate.getTime() + tzOffsetMs));
			}
			return "";
		},

		/**
		 * Recipe State Formatter
		 */
		getRecipeStatusState: function (status) {
			var retStatus = "None";
			if (status) {
				if (status === "300" || // Released
					status === "310") { // Released for Production
					retStatus = "Success";
				} else if (status === "410") { // Obselete
					retStatus = "Error";
				} else if (status === "100") { // WIP
					retStatus = "None";
				}
			}
			return retStatus;
		},

		/**
		 * Recipe Status Icon Formatter
		 */
		getRecipeStatusIcon: function (status) {
			var retStatus = "sap-icon://status-in-process";

			if (status === "300" || // Released
				status === "310") { // Released for Production
				retStatus = "sap-icon://status-completed";
			} else if (status === "410") { // Obselete
				retStatus = "sap-icon://status-negative";
			} else if (status === "100") { // WIP
				retStatus = "sap-icon://status-in-process";
			}

			return retStatus;
		},

		getRecipeVersion: function (alt, ver) {
			if (alt && ver) {
				return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("recipetable.row.Version", [alt, ver]);
			}
			return "";
		},

		getChangeIconColor: function (change) {
			var retVal = "black";
			if (change) {
				if (change === "C") {
					retVal = "#3498db";
				} else if (change === "D") {
					retVal = "#e74c3c";
				} else if (change === "U") {
					retVal = "#9b59b6";
				}
			}

			return retVal;
		},

		getOldChangeIcon: function (change) {
			var retVal = "sap-icon://busy";
			if (change) {
				if (change === "C") {
					retVal = "sap-icon://add";
				} else if (change === "D") {
					retVal = "sap-icon://less";
				} else if (change === "U") {
					retVal = "sap-icon://edit";
				}
			}

			return retVal;
		},

		getNewChangeIcon: function (change) {
			var retVal = "sap-icon://busy";
			if (change) {
				if (change === "C") {
					retVal = "sap-icon://add";
				} else if (change === "D") {
					retVal = "sap-icon://less";
				} else if (change === "U") {
					retVal = "sap-icon://unfavorite";
				}
			}

			return retVal;
		},

		isOldValueIconVisible: function (change) {
			var retVal = false;
			if (change) {
				if (change === "C") {
					retVal = false;
				} else if (change === "D") {
					retVal = true;
				} else if (change === "U") {
					retVal = true;
				}
			}

			return retVal;
		},

		isNewValueIconVisible: function (change) {
			var retVal = false;
			if (change) {
				if (change === "C") {
					retVal = true;
				} else if (change === "D") {
					retVal = false;
				} else if (change === "U") {
					retVal = true;
				}
			}

			return retVal;
		},
		
		formatUsages: function (inclusion, exclusion) {
			var retVal = "";
			if (inclusion) {
				retVal += inclusion;
			}
			if (exclusion && exclusion.length > 0) {
				retVal += "\n" + this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("detailtable.column.Exclude") + ": " +
					exclusion;
			}

			return retVal;
		}
	};
});