/**
 * App View Controller
 * 
 * This is the view controller for the Empty Page view. 
 *
 * @author Kush Patel.
 * 
 * Date         Version     Modified By     Description
 * Mar 25 2019   1.0         PATELK          Initial Version
 */
sap.ui.define([
	"com/merck/ipi/ecnreport/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("com.merck.ipi.ecnreport.controller.EmptyPage", {
		/**
		 * Navigates to the worklist when the link is pressed
		 * @public
		 */
		onBackPressed: function() {
			this.getRouter().navTo("objectList", {});
		}
	});
});