sap.ui.define([
	"com/merck/ipi/ecnreport/controller/BaseController",
	"com/merck/ipi/ecnreport/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment"
], function (BaseController, formatter, JSONModel, Sorter, Filter, FilterOperator, Fragment) {
	"use strict";
	return BaseController.extend("com.merck.ipi.ecnreport.controller.CreateRecordView", {
		formatter: formatter, // the formatter
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.merck.ipi.ecnreport.view.ObjectDetailsView
		 */
		onInit: function () {
			// set context density
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

			// Get Context Path for details screen
			var oRouter = this.getRouter();
			oRouter.getRoute("objectDetails").attachMatched(this._onRouteMatched, this);
			
			// this.getView().byId("Impacted").setShowNextButton(false);  //Hides Next Button
			
			// Fragment.load({
			// 	name: "com.merck.ipi.ecnreport.view.fragment.Review",
			// 	controller: this
			// }).then(function (oWizardReviewPage) {
			// 	this._oWizardReviewPage = oWizardReviewPage;
			// 	this._oNavContainer.addPage(this._oWizardReviewPage);
			// }.bind(this));
		},
		
			onCancel: function() {
				this.getRouter().navTo("objectList");
				this.byId("objectHeader").setNumber("----");
			//	var firstStep = this.getView().byId('Initialize');
			//	this.getView().byId('CreateWizard').goToStep(firstStep);
				this.byId("CreateWizard").discardProgress(this.getView().byId("Initialize"));
			//	this.byId("CreateWizard").invalidateStep(this.getView().byId("Design"));
			//	this.byId("CreateWizard").invalidateStep(this.getView().byId("Scoping"));
				this.byId("CreateWizard").setCurrentStep(this.getView().byId("Initialize"));
				
		},
		
		onActivate: function(oEvent) {
			this.byId("objectHeader").setNumber("34761");
			this.byId("Scoping")._oNextButton.setVisible(false);
			// this.byId("objectHeader").setNumberUnit("Changer Number");
		}
		

		
		// 	wizardCompletedHandler: function () {
		// 	this._oNavContainer.to(this._oWizardReviewPage);
		// }
	
	});
});