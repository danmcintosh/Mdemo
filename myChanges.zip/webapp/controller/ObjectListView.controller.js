/**
 * Specification Change Report List View Controller
 * 
 * This is the view controller for the Object List view. This view allows the user
 * to search for specification change reports.
 *
 * @author Kush Patel.
 * 
 * Date         Version     Modified By     Description
 * Mar 25 2019   1.0         PATELK          Initial Version
 */
sap.ui.define([
	"com/merck/ipi/ecnreport/controller/BaseController",
	"com/merck/ipi/ecnreport/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, formatter, JSONModel, Sorter, DateFormat, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.merck.ipi.ecnreport.controller.ObjectListView", {
		formatter: formatter, // the formatter

		/****************************
		 * LIFECYCLE METHODS BEGIN	*
		 ****************************/

		/**
		 * This method is called upon initialization of the View. The controller can perform its internal setup 
		 * in this hook. It is only called once per View instance, unlike the onBeforeRendering and 
		 * onAfterRendering hooks. (Even though this method is declared as "abstract", it does not need to be 
		 * defined in controllers, if the method does not exist, it will simply not be called.)
		 */
		onInit: function () {
			// set context density
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		//	this.showSpinner();
			// initialize local view model
			var viewModel = new JSONModel({
				tableTitle: this.getResourceBundle().getText("table.header.SpecChangeCount", [0]), // The table header
				headerExpanded: true, // Is the header expanded
				secondDateValue: new Date(new Date().setHours(0, 0, 0, 0)), // second selected date - today 
				dateValue: new Date(new Date(new Date().setDate(new Date().getDate() - 1)).setHours(0, 0, 0, 0)), // first selected date - yesterday .setDate(d.getDate() - 1)
				maxDate: new Date(), // the current date - max selection on date picker
				filterSearchValue: "", // The generic search value
				filterPlantDisplayValue: "", // The plant displayed in the filter
				filterPlantValue: "", // The selected plant number
				filterMaterialDisplayValue: "", // The material displayed in the filter
				filterMaterialValue: "", // The selected material number,
				selectedRecipeTypeKeys: "", // The selected recipe type keys,
				basicSearchText: "",
				keyDateValueState: "None", // state of the key date
				selectedCriteriaValueStateText: "", // text for key criteria
				keyDateValueStateText: "", // text for key date
				selectedFilterSpecTypeValues: [], //selected Specification Type filter values
				selectedFilterProductValues: [], //selected Product filter value
				selectedFilterSubstanceFamilyValues: [], //selected SubstanceFamily Alias filter value
				selectedFragmentContexts: null,
				changes: [{
					programId: "54",
					description: "Supply Chain Change",
					initiator: "Chuck Phillips",
					status: "Completed",
					state: "Success",
					changeOwner: "Chuck Phillips"
				}, 	{
					programId: "12",
					description: "Material Change",
					initiator: "Charlie Mccormick",
					status: "In Progress",
					state: "Warning",
					changeOwner: "Charlie Mccormick"
				}, {
					programId: "34",
					description: "Implementation Change",
					initiator: "Steve Quinn",
					status: "Rejected",
					state: "Error",
					changeOwner: "Charlie Mccormick"
				}]
			});
			viewModel.setDefaultBindingMode("TwoWay");
			this.setModel(viewModel, "viewModel");
		//	this.performSearch();

			// var oRouter = this.getRouter();
			// oRouter.getRoute("objectList").attachMatched(this.performSearch, this);
		},

		/**
		 * This method is called upon desctuction of the View. The controller should perform its internal 
		 * destruction in this hook. It is only called once per View instance, unlike the onBeforeRendering 
		 * and onAfterRendering hooks. (Even though this method is declared as "abstract", it does not need 
		 * to be defined in controllers, if the method does not exist, it will simply not be called.)
		 */
		onExit: function () {
			if (this._oFilterSelectionDialog) {
				this._oFilterSelectionDialog.destroy();
			}
		},

		/**
		 * This method is called every time the View is rendered, after the HTML is placed in the DOM-Tree. 
		 * It can be used to apply additional changes to the DOM after the Renderer has finished. (Even 
		 * though this method is declared as "abstract", it does not need to be defined in controllers, 
		 * if the method does not exist, it will simply not be called.)
		 */
		onAfterRendering: function () {

		},

		/**
		 * This method is called every time the View is rendered, before the Renderer is called and the 
		 * HTML is placed in the DOM-Tree. It can be used to perform clean-up-tasks before re-rendering. 
		 * (Even though this method is declared as "abstract", it does not need to be defined in 
		 * controllers, if the method does not exist, it will simply not be called.)
		 */
		onBeforeRendering: function () {

		},

		/****************************
		 * LIFECYCLE METHODS END	*
		 ****************************/

		/****************************
		 * TABLE HANDLERS BEGIN		*
		 ****************************/
		/**
		 * Handler for when table item pressed - navigates to ObjectDetialView and stores selected item details
		 */
		onItemPressed: function (oEvent) {
			var selectedObject = oEvent.getSource().getBindingContext("reportModel").getObject();

			//Store selected object in shared model - used for ObjectDetailView header
			this.getOwnerComponent().getModel("sharedViewModel").setProperty("/selectedObject", selectedObject);

			this.showSpinner();
			this.getRouter().navTo(
				"objectDetails", {
					Specification: selectedObject.Specification,
					ECN: selectedObject.ECN
				});
		},
		
		onAdd: function() {
				this.getRouter().navTo("createRecord");
		},

		/**
		 * Handler for when the table refresh has been completed - controls header count
		 */
		onReportTableUpdateFinished: function (oEvent) {
			this.getModel("viewModel").setProperty("/tableTitle", this.getResourceBundle().getText("table.header.SpecChangeCount", "" + oEvent.getParameter(
				"total")));
		},

		/**
		 * Perform Report Search
		 */
		performSearch: function (oEvent) {

			if (!this.validateFilters()) {
				return;
			}
			this.showSpinner();
			var aFilters = new Filter({
				filters: [],
				and: true
			});

			var selectedFirstDate = this.getView().getModel("viewModel").getProperty("/dateValue");
			var selectedSecondDate = this.getView().getModel("viewModel").getProperty("/secondDateValue");
			var tzOffsetMs = selectedFirstDate.getTimezoneOffset() * 60 * 1000;
			var formattedFirstDate = new Date(selectedFirstDate.getTime() - tzOffsetMs);
			tzOffsetMs = selectedSecondDate.getTimezoneOffset() * 60 * 1000;
			var formattedSecondDate = new Date(selectedSecondDate.getTime() - tzOffsetMs);
			var dateRangeFilter = new Filter({
				path: "ChangeReleaseDate",
				operator: FilterOperator.BT,
				value1: formattedFirstDate,
				value2: formattedSecondDate
			});
			aFilters.aFilters.push(dateRangeFilter);

			/* Add filters from Product */
			var selectedProduct = this.getView().getModel("viewModel").getProperty("/selectedFilterProductValues");

			if (selectedProduct.length > 0) {
				aFilters.aFilters.push(
					new Filter({
						path: "Product",
						operator: FilterOperator.EQ,
						value1: selectedProduct[0].filterProductId
					})
				);
			}
			/* Add filters from Substance Family Alias*/
			var selectedSubstanceFamily = this.getView().getModel("viewModel").getProperty("/selectedFilterSubstanceFamilyValues");

			if (selectedSubstanceFamily.length > 0) {
				aFilters.aFilters.push(
					new Filter({
						path: "SubstanceFamily",
						operator: FilterOperator.EQ,
						value1: selectedSubstanceFamily[0].filterCriteriaText
					})
				);
			}

			/* Add filters from Specification Type */
			var selectedSpecType = this.getView().getModel("viewModel").getProperty("/selectedFilterSpecTypeValues");

			if (selectedSpecType.length > 0) {
				var specTypeFilterSet = new Filter({
					filters: selectedSpecType.map(function (item) {
						return new Filter({
							path: "SpecTypeID",
							operator: FilterOperator.EQ,
							value1: item
						});
					}.bind(this)),
					and: false
				});
				aFilters.aFilters.push(specTypeFilterSet);
			}

			// this.getOwnerComponent().getModel("s4ReportModel").read(
			// 	// "/ZGSPC_C_ECNREPORT(P_KeyDate=datetime'" + encodeURIComponent(formattedDate) + "')/Set", {
			// 	"/ZGSPC_C_ECNREPORT", {
			// 		filters: aFilters.aFilters,
			// 		success: function (data) {
			// 			// we initialize the model here so as to avoid 
			// 			// race condition. all views can now access the model
			// 			var oModel = new JSONModel({});
			// 			oModel.setData(data.results);
			// 			this.getView().setModel(oModel, "reportModel");
			// 			this.hideSpinner();
			// 		}.bind(this),
			// 		error: function (error) {
			// 			jQuery.sap.log.error("ERROR: " + JSON.stringify(error));
			// 			//reject(error);
			// 			this.hideSpinner();
			// 		}.bind(this)
			// 	}
			// );
		},

		/**
		 * Main code for exporting PDF file, takes input RepRequest -> H = High-Level Report, D = Detailed Report
		 */
		exportPDF: function (RepRequest) {
			sap.m.MessageToast.show(this.getResourceBundle().getText("message.info.FileDownload"));
			var aFilters = new Filter({
				filters: [],
				and: true
			});
			// 2019-04-01T00:00:00
			var selectedFirstDate = this.getView().getModel("viewModel").getProperty("/dateValue");
			var selectedSecondDate = this.getView().getModel("viewModel").getProperty("/secondDateValue");
			var oDateFormat = DateFormat.getDateTimeInstance({
				pattern: "YYYY-MM-ddThh:mm:ss"
			});
			var formattedFirstDate = oDateFormat.format(new Date(selectedFirstDate.getTime()));
			var formattedSecondDate = oDateFormat.format(new Date(selectedSecondDate.getTime()));
			var dateRangeFilter = new Filter({
				path: "ChangeReleaseDate",
				operator: FilterOperator.BT,
				value1: formattedFirstDate,
				value2: formattedSecondDate
			});
			aFilters.aFilters.push(dateRangeFilter);

			var sURL =
				this.getOwnerComponent().getModel("s4ReportModel").sServiceUrl +
				"/SpecChgRepPDFSet(RepRequest='" + RepRequest + "')/$value?$filter=(ChangeReleaseDate ge datetime'" + formattedFirstDate +
				"' and ChangeReleaseDate le datetime'" + formattedSecondDate + "')";

			var selectedProduct = this.getView().getModel("viewModel").getProperty("/selectedFilterProductValues");
			if (selectedProduct.length !== 0) {
				sURL = sURL.concat(" and Product eq '" + selectedProduct[0].filterProductId + "'");
			}

			var selectedSubstanceFamily = this.getView().getModel("viewModel").getProperty("/selectedFilterSubstanceFamilyValues");
			if (selectedSubstanceFamily.length !== 0) {
				sURL = sURL.concat(" and SubstanceFamily eq '" + selectedSubstanceFamily[0].filterCriteriaText + "'");
			}

			var selectedSpecType = this.getView().getModel("viewModel").getProperty("/selectedFilterSpecTypeValues");
			if (selectedSpecType.length !== 0) {
				var specTypeFilterText = " and ( ";
				for (var i = 0; i < selectedSpecType.length; i++) {
					specTypeFilterText = specTypeFilterText.concat("SpecTypeID eq '" + selectedSpecType[i] + "'");
					if (i !== selectedSpecType.length - 1) {
						specTypeFilterText = specTypeFilterText.concat(" or ");
					}
				}
				specTypeFilterText = specTypeFilterText.concat(")");
				sURL = sURL.concat(specTypeFilterText);
			}

			var oReq = new XMLHttpRequest();
			oReq.open("GET", sURL, true);
			oReq.responseType = "blob";
			oReq.onload = function (oEvent) {
				var blob = new Blob([oReq.response], {
						type: "application/pdf"
					}),
					fileName = "";

				//set file name to be either for Summary or Detailed
				if (RepRequest === "H") {
					fileName = this.getResourceBundle().getText("appTitle") + " - " + this.getResourceBundle().getText("button.ExportSummary");
				} else if (RepRequest === "D") {
					fileName = this.getResourceBundle().getText("appTitle") + " - " + this.getResourceBundle().getText("button.ExportDetailed");
				}

				if (sap.ui.Device.browser.msie || sap.ui.Device.browser.edge) { // IE / Edge
					window.navigator.msSaveOrOpenBlob(blob, fileName + ".pdf");
				} else {
					var link = document.createElement("a");
					if (link.download !== undefined) {
						// Browsers that support HTML5 download attribute
						var objectUrl = URL.createObjectURL(blob);
						link.setAttribute("href", objectUrl);
						link.setAttribute("download", fileName);
						link.style = "visibility:hidden";
						document.body.appendChild(link); // eslint-disable-line sap-no-dom-insertion,sap-no-proprietary-browser-api
						link.click();
						document.body.removeChild(link); // eslint-disable-line sap-no-dom-insertion,sap-no-proprietary-browser-api
					} else {
						// browsers that don't support download attribute
						objectUrl = window.URL.createObjectURL(blob);
						sap.m.URLHelper.redirect(objectUrl, true);
					}
				}
			}.bind(this);

			oReq.ontimeout = function (errorThrown) {
				sap.m.MessageBox.error(this.getResourceBundle().getText("message.failure.TimeoutError"), {
					title: this.getResourceBundle().getText("message.failure.TimeoutErrorTitle"),
					icon: sap.m.MessageBox.Icon.ERROR,
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () {}
				});
			}.bind(this);

			oReq.send();
		},

		/****************************
		 * TABLE HANDLERS END		*
		 ****************************/

		/****************************
		 * FILTER HANDLERS BEGIN		*
		 ****************************/
		/**
		 * Handler for when token removed from Product filter
		 */
		onProductTokenUpdate: function (oEvent) {
			var type = oEvent.getParameter("type"),
				remainingData = this.getView().getModel("viewModel").getProperty("/selectedFilterProductValues");
			if (type === "removed") {
				var removedKey = oEvent.getParameter("removedTokens")[0].getKey();
				remainingData = this.onChangeValueTokenUpdated(removedKey, remainingData);
			}

			this.getView().getModel("viewModel").setProperty("/selectedFilterProductValues", remainingData);
			// perform search
			this.performSearch();
		},

		/**
		 * Handler for when token removed from Substance Family filter
		 */
		onSubstanceFamilyTokenUpdate: function (oEvent) {
			var type = oEvent.getParameter("type"),
				remainingData = this.getView().getModel("viewModel").getProperty("/selectedFilterSubstanceFamilyValues");

			if (type === "removed") {
				var removedKey = oEvent.getParameter("removedTokens")[0].getKey();
				remainingData = this.onChangeValueTokenUpdated(removedKey, remainingData);
			}

			this.getView().getModel("viewModel").setProperty("/selectedFilterSubstanceFamilyValues", remainingData);
			// perform search
			this.performSearch();
		},
		/**
		 * Criteria token removed
		 */
		onChangeValueTokenUpdated: function (removedKey, remainingData) {
			// token removed
			for (var i = 0; i < remainingData.length; i++) {
				if (remainingData[i].filterCriteriaKey === removedKey) {
					remainingData.splice(i, 1);
					break;
				}
			}
			return remainingData;
		},

		/**
		 * Product Fragment Search Handler
		 */
		showProductFilterValueHelp: function (oEvent) {
			/* Product Filter Dialog */
			this._oProductSelectionDialog = sap.ui.xmlfragment("com.merck.ipi.ecnreport.view.fragment.ProductFilterDialog", this);

			// add basic search
			var oBasicSearch = new sap.m.SearchField({
				value: "{viewModel>/basicSearchText}",
				showSearchButton: true,
				search: this.onProductFragmentSearch.bind(this)
			});
			sap.ui.getCore().byId("productsFragmentFilterBar").setBasicSearch(oBasicSearch);

			// check if any rows were selected
			if (this.getView().getModel("viewModel").getProperty("/selectedFilterProductValues").length > 0) {
				var selectedContextPaths = this.getView().getModel("viewModel").getProperty("/selectedFilterProductValues").map(function (sel) {
					return "/ZGSPC_C_PRODMAT(ProductId='" + encodeURIComponent(sel.filterProductId) + "',SpecificationId='" + encodeURIComponent(
							sel.filterCriteriaKey) +
						"',SubstanceSpecId='" + sel.filterSubstanceSpecId + "',ProductName='" + encodeURIComponent(sel.filterCriteriaText) +
						"',SubFamAlias='" + encodeURIComponent(sel.filterCriteriaSubFamilyAlias) +
						"',TradeName='" + encodeURIComponent(sel.filterTradeName) + "')";
				});
			}
			//handle last selected value
			this.getView().getModel("viewModel").setProperty("/selectedFragmentContexts", selectedContextPaths);

			//handle pressing escape while fragment is open
			this._oProductSelectionDialog.setEscapeHandler(function () {
				this.onProductFragmentCancel();
			}.bind(this));

			this.attachControl(this._oProductSelectionDialog);
			this._oProductSelectionDialog.open();
		},

		/**
		 * Substance Family Fragment Search Handler
		 */
		showSubstanceFamilyFilterValueHelp: function (oEvent) {
			/* Substance Family Filter Dialog */
			this._oSubstanceFamilySelectionDialog = sap.ui.xmlfragment("com.merck.ipi.ecnreport.view.fragment.SubstanceFamilyFilterDialog",
				this);

			// add basic search
			var oBasicSearch = new sap.m.SearchField({
				value: "{viewModel>/basicSearchText}",
				showSearchButton: true,
				search: this.onSubstanceFamilyFragmentSearch.bind(this)
			});
			sap.ui.getCore().byId("substanceFamilyFragmentFilterBar").setBasicSearch(oBasicSearch);

			// check if any rows were selected
			if (this.getView().getModel("viewModel").getProperty("/selectedFilterSubstanceFamilyValues").length > 0) {
				var selectedContextPaths = this.getView().getModel("viewModel").getProperty("/selectedFilterSubstanceFamilyValues").map(function (
					sel) {
					return "/ZGPLM_C_SUBFAM('" + encodeURIComponent(sel.filterCriteriaKey) + "')";
				});
			}
			this.getView().getModel("viewModel").setProperty("/selectedFragmentContexts", selectedContextPaths);

			//handle pressing escape while fragment is open
			this._oSubstanceFamilySelectionDialog.setEscapeHandler(function () {
				this.onSubstanceFamilyFragmentCancel();
			}.bind(this));

			this.attachControl(this._oSubstanceFamilySelectionDialog);
			this._oSubstanceFamilySelectionDialog.open();
		},
		/****************************
		 * FILTER HANDLERS END		*
		 ****************************/

		/****************************
		 * FRAGMENT HANDLERS BEGIN	*
		 ****************************/

		/**
		 * Product Fragment Search Handler
		 */
		onProductFragmentSearch: function (oEvent) {
			sap.ui.getCore().byId("productsFragmentTable").bindItems({
				path: "s4SearchHelpModel>/ZGSPC_C_PRODMAT",
				sorter: [new Sorter("ProductId", false)],
				filters: new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("ProductId", sap.ui.model.FilterOperator.Contains,
							oEvent.getParameter("query")),
						new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains,
							oEvent.getParameter("query")),
						new sap.ui.model.Filter("TradeName", sap.ui.model.FilterOperator.Contains,
							oEvent.getParameter("query")),
						new sap.ui.model.Filter("SubFamAlias", sap.ui.model.FilterOperator.Contains,
							oEvent.getParameter("query"))
					],
					and: false
				}),
				template: sap.ui.getCore().byId("productsFragmentTable").getBindingInfo("items").template
			});
			// initialize selections
			sap.ui.getCore().byId("productsFragmentTable").setSelectedContextPaths(this.getView().getModel("viewModel").getProperty(
				"/selectedFragmentContexts"));
		},

		/**
		 * Product Fragment Close Handler
		 */
		onProductFragmentConfirm: function (oEvent) {
			var selectedProduct = sap.ui.getCore().byId("productsFragmentTable").getSelectedItem().getBindingContext("s4SearchHelpModel").getObject(),
				productDataItem = {
					"filterProductId": selectedProduct.ProductId,
					"filterSubstanceSpecId": selectedProduct.SubstanceSpecId,
					"filterCriteriaKey": selectedProduct.SpecificationId,
					"filterCriteriaText": selectedProduct.ProductName,
					"filterCriteriaSubFamilyAlias": selectedProduct.SubFamAlias,
					"filterTradeName": selectedProduct.TradeName,
					"filterSubFamAlias": selectedProduct.SubFamAlias
				};
			this.getView().getModel("viewModel").setProperty("/selectedFilterProductValues", [productDataItem]);

			// perform search
			this.performSearch();

			// destroy fragment (for reuse)
			this._oProductSelectionDialog.destroy();
			this._oProductSelectionDialog = null;

			// clear search
			this.getView().getModel("viewModel").setProperty("/basicSearchText", "");

			// clear selection
			this.getView().getModel("viewModel").setProperty("/selectedFragmentContexts", null);
		},

		/**
		 * Product Fragment Cancel Handler
		 */
		onProductFragmentCancel: function (oEvent) {
			// destroy fragment (for reuse)
			this._oProductSelectionDialog.destroy();
			this._oProductSelectionDialog = null;

			// clear search
			this.getView().getModel("viewModel").setProperty("/basicSearchText", "");

			// clear selection
			this.getView().getModel("viewModel").setProperty("/selectedFragmentContexts", null);
		},

		/**
		 * Substance Family Fragment Search Handler
		 */
		onSubstanceFamilyFragmentSearch: function (oEvent) {
			sap.ui.getCore().byId("substanceFamilyFragmentTable").bindItems({
				path: "s4SearchHelpModel>/ZGPLM_C_SUBFAM",
				filters: new sap.ui.model.Filter("SubFamAlias", sap.ui.model.FilterOperator.Contains,
					oEvent.getParameter("query")),
				template: sap.ui.getCore().byId("substanceFamilyFragmentTable").getBindingInfo("items").template,
				parameters: {
					select: "SubFamAlias"
				}
			});
			// initialize selections
			sap.ui.getCore().byId("substanceFamilyFragmentTable").setSelectedContextPaths(this.getView().getModel("viewModel").getProperty(
				"/selectedFragmentContexts"));
		},

		/**
		 * Substance Family Fragment Close Handler
		 */
		onSubstanceFamilyFragmentConfirm: function (oEvent) {
			var selectedSubstanceFamily = sap.ui.getCore().byId("substanceFamilyFragmentTable").getSelectedItem().getBindingContext(
					"s4SearchHelpModel").getObject(),

				substanceFamilyDataItem = {
					"filterCriteriaKey": selectedSubstanceFamily.SubFamAlias,
					"filterCriteriaText": selectedSubstanceFamily.SubFamAlias
				};

			this.getView().getModel("viewModel").setProperty("/selectedFilterSubstanceFamilyValues", [substanceFamilyDataItem]);

			// perform search
			this.performSearch();

			// destroy fragment (for reuse)
			this._oSubstanceFamilySelectionDialog.destroy();
			this._oSubstanceFamilySelectionDialog = null;

			// clear search
			this.getView().getModel("viewModel").setProperty("/basicSearchText", "");

			// clear selection
			this.getView().getModel("viewModel").setProperty("/selectedFragmentContexts", null);
		},

		/**
		 * Substance Family Fragment Cancel Handler
		 */
		onSubstanceFamilyFragmentCancel: function (oEvent) {
			// destroy fragment (for reuse)
			this._oSubstanceFamilySelectionDialog.destroy();
			this._oSubstanceFamilySelectionDialog = null;

			// clear search
			this.getView().getModel("viewModel").setProperty("/basicSearchText", "");

			// clear selection
			this.getView().getModel("viewModel").setProperty("/selectedFragmentContexts", null);
		},

		/**
		 * Keeps track of the selected items in a fragment
		 */
		onFragmentSelectionChanged: function (oEvent) {
			// keep a backup of the selected paths in the current fragment
			this.getView().getModel("viewModel").setProperty("/selectedFragmentContexts", sap.ui.getCore().byId(oEvent.getSource().getId()).getSelectedContextPaths());
		},

		onFragmentTableUpdateStarted: function (oEvent) {
			sap.ui.getCore().byId(oEvent.getSource().getId()).setSelectedContextPaths(this.getView().getModel("viewModel").getProperty(
				"/selectedFragmentContexts"));
		},

		/**
		 * Export PDF Fragment/Popup Handler
		 */
		onExportPopover: function (oEvent) {

			// create popover
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("com.merck.ipi.ecnreport.view.fragment.ExportToPDF", this);
				this.getView().addDependent(this._oPopover);
			}

			this._oPopover.openBy(oEvent.getSource());
		},

		/**
		 * Export High-Level Report handle
		 */
		exportHighLevel: function (oEvent) {
			this.exportPDF("H");
			this._oPopover.close();
		},

		/**
		 * Export Detailed Report handle
		 */
		exportDetailed: function (oEvent) {
			this.exportPDF("D");
			this._oPopover.close();

		},
		/****************************
		 * FRAGMENT HANDLERS END	*
		 ****************************/

		/****************************
		 * DATA ACCESS LAYER BEGIN	*
		 ****************************/
		/**
		 * Check if mandatory filters are populated and date range is within 30 days
		 */
		validateFilters: function () {
			var retVal = true;
			this.getView().getModel("viewModel").setProperty("/keyDateValueState", sap.ui.core.ValueState.None);

			if ((this.getView().getModel("viewModel").getProperty("/dateValue") === null) || (this.getView().getModel("viewModel").getProperty(
					"/secondDateValue") === null)) {
				// nothing selected
				retVal = false;
				this.getView().getModel("viewModel").setProperty("/keyDateValueState", sap.ui.core.ValueState.Error);
				this.getView().getModel("viewModel").setProperty("/keyDateValueStateText", this.getResourceBundle().getText(
					"filter.message.SelectKeyDate"));
				this.getView().getModel("reportModel").setData([]);
			}

			if (this.daysBetween(this.getView().getModel("viewModel").getProperty("/dateValue"), this.getView().getModel("viewModel").getProperty(
					"/secondDateValue")) > 30) {
				retVal = true;
				this.getView().getModel("viewModel").setProperty("/keyDateValueState", sap.ui.core.ValueState.Warning);
				this.getView().getModel("viewModel").setProperty("/keyDateValueStateText", this.getResourceBundle().getText(
					"filter.message.SelectRecommend"));
				this.getView().getModel("reportModel").setData([]);
			}

			return retVal;
		},

		daysBetween: function (startDate, endDate) {
			var millisecondsPerDay = 24 * 60 * 60 * 1000;
			return (this.treatAsUTC(endDate) - this.treatAsUTC(startDate)) / millisecondsPerDay;
		}

		/****************************
		 * DATA ACCESS LAYER END	*
		 ****************************/

	});
});