sap.ui.define([
	"com/merck/ipi/ecnreport/controller/BaseController",
	"com/merck/ipi/ecnreport/model/formatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, formatter, JSONModel, Sorter, DateFormat, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.merck.ipi.ecnreport.controller.Step4Shell", {
		formatter: formatter, // the formatter

		/****************************
		 * LIFECYCLE METHODS BEGIN	*
		 ****************************/

		/**
		 * This method is called upon initialization of the View. The controller can perform its internal setup 
		 * in this hook. It is only called once per View instance, unlike the onBeforeRendering and 
		 * onAfterRendering hooks. (Even though this method is declared as "abstract", it does not need to be 
		 * defined in controllers, if the method does not exist, it will simply not be called.)
		 */
		onInit: function () {
			// set context density
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			var viewModel = new JSONModel({
				nodeRoot: {
					children: {
						children: [{
							children: [
							// 	{
							// 	CCvisible: false,
							// 	elementPositionNumber: 0,
							// 	recipeProcessElementType: "RECIPE",
							// 	recipeProcessElementUUID: 0,
							// 	subtitle: "Sub-Sub Task-1",
							// 	text: "Sub-Sub Task-1"
							// }
							],
							CCvisible: false,
							elementPositionNumber: 0,
							recipeProcessElementType: "RECIPE",
							recipeProcessElementUUID: 0,
							subtitle: "Sub Task-1",
							text: "Sub Task-1",
							products: [{
								productName: "Elonva",
								productId: "1243"
							}],
							sites: [{
								siteName: "Brazil",
								siteCountry: "Brazil"
							}, {
								siteName: "Oss",
								siteCountry: "EU"
							}]
						}, {
							CCvisible: false,
							elementPositionNumber: 0,
							recipeProcessElementType: "RECIPE",
							recipeProcessElementUUID: 0,
							subtitle: "Sub Task-2",
							text: "Sub Task-2",
							products: [{
								productName: "Orgalutran",
								productId: "2355"
							}, {
								productName: "Puregon",
								productId: "3462"
							}],
							sites: [{
								siteName: "Wilson",
								siteCountry: "US"
							}, {
								siteName: "Heist",
								siteCountry: "EU"
							}]
						}],
						CCvisible: true,
						elementPositionNumber: 0,
						recipeProcessElementType: "RECIPE",
						recipeProcessElementUUID: 0,
						subtitle: "Some Description",
						text: "Lead Change",
						products: [{
							productName: "Elonva",
							productId: "1243"
						}, {
							productName: "Orgalutran",
							productId: "2355"
						}, {
							productName: "Puregon",
							productId: "3462"
						}],
						sites: [{
							siteName: "Brazil",
							siteCountry: "Brazil"
						}, {
							siteName: "Oss",
							siteCountry: "EU"
						}, {
							siteName: "Wilson",
							siteCountry: "US"
						}, {
							siteName: "Heist",
							siteCountry: "EU"
						}],
						changes: [{
							productName: "Elonva",
							siteName: "Brazil",
							MAH: "Merck",
							country: "Brazil",
							apKey: 0,
							riKey: 0
						}, {
							productName: "Elonva",
							siteName: "Oss",
							MAH: "Merck",
							country: "EU",
							apKey: 0,
							riKey: 0
						}, {
							productName: "Elonva",
							siteName: "Wilson",
							MAH: "Bayer",
							country: "US",
							apKey: 0,
							riKey: 0
						}, {
							productName: "Elonva",
							siteName: "Heist",
							MAH: "Merck",
							country: "EU",
							apKey: 0,
							riKey: 0
						}]
					}
				}
			});
			viewModel.setDefaultBindingMode("OneWay");

			var selectedModel = new JSONModel({
				CCvisible: true,
				elementPositionNumber: 0,
				recipeProcessElementType: "RECIPE",
				recipeProcessElementUUID: 0,
				subtitle: "Some Description",
				text: "Lead Change",
				products: [{
					productName: "Elonva",
					productId: "1243"
				}, {
					productName: "Orgalutran",
					productId: "2355"
				}, {
					productName: "Puregon",
					productId: "3462"
				}],
				sites: [{
					siteName: "Brazil",
					siteCountry: "Brazil"
				}, {
					siteName: "Oss",
					siteCountry: "EU"
				}, {
					siteName: "Wilson",
					siteCountry: "US"
				}, {
					siteName: "Heist",
					siteCountry: "EU"
				}],
				changes: [{
					productName: "Elonva",
					siteName: "Brazil",
					MAH: "Merck",
					country: "Brazil",
					apKey: 0,
					riKey: 0
				}, {
					productName: "Elonva",
					siteName: "Oss",
					MAH: "Merck",
					country: "EU",
					apKey: 0,
					riKey: 0
				}, {
					productName: "Elonva",
					siteName: "Wilson",
					MAH: "Bayer",
					country: "US",
					apKey: 0,
					riKey: 0
				}, {
					productName: "Elonva",
					siteName: "Heist",
					MAH: "Merck",
					country: "EU",
					apKey: 0,
					riKey: 0
				}]
			});
			viewModel.setDefaultBindingMode("TwoWay");

			this.setModel(selectedModel, "selectedModel");
			this.setModel(viewModel, "viewModel");
			this.byId("recipeTree").expandToLevel(1);

		},

		onProcessTreeItemSelectionChange: function (oEvent) {
			this.getView().getModel("selectedModel").setData(oEvent.getParameter("listItem").getBindingContext("viewModel").getObject());
		}

	});
});