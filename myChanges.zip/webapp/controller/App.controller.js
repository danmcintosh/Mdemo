/**
 * App View Controller
 *
 * This is the view controller for the App view. This is the view inside which the rest of the views are loaded.
 *
 * @author Kush Patel.
 *
 * Date         Version     Modified By     Description
 * Mar 25 2019   1.0         PATELK          Initial Version
 */
sap.ui.define([
	"com/merck/ipi/ecnreport/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/merck/ipi/ecnreport/util/utilities",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, utilities, MessageBox) {
	"use strict";

	return BaseController.extend("com.merck.ipi.ecnreport.controller.App", {
		onInit: function () {
			// initialize shared view model
			var sharedViewModel = new JSONModel({
				appBusy: false
			});
			sharedViewModel.setDefaultBindingMode("OneWay");
			this.getOwnerComponent().setModel(sharedViewModel, "sharedViewModel");
			// ZGSPC_ECN_REP_SRV
			// initialize s/4 models

			// var s4ReportModel = new sap.ui.model.odata.v2.ODataModel(
			// 	"/sap/opu/odata/sap/ZGSPC_ECN_REP_SRV/", {
			// 		json: true,
			// 		loadMetadataAsync: true,
			// 		defaultBindingMode: "OneWay",
			// 		useBatch: true,
			// 		tokenHandling: true
			// 	});
			// s4ReportModel.attachMetadataFailed(function (mArgs) {
			// 	// could not interact with S/4
			// 	this.handleMetadataFailure(mArgs);
			// }, this);
			// //s4ReportModel.setSizeLimit(10);
			// this.getOwnerComponent().setModel(s4ReportModel, "s4ReportModel");

			// var s4SearchHelpModel = new sap.ui.model.odata.v2.ODataModel(
			// 	"/sap/opu/odata/sap/ZGPLM_SRCHHLP_SRV/", {
			// 		json: true,
			// 		maxDataServiceVersion: "4.0",
			// 		loadMetadataAsync: true,
			// 		defaultBindingMode: "OneWay",
			// 		useBatch: true,
			// 		tokenHandling: true,
			// 		defaultCountMode: "None"
			// 	});
			// s4SearchHelpModel.attachMetadataFailed(function (mArgs) {
			// 	// could not interact with S/4
			// 	this.handleMetadataFailure(mArgs);
			// }, this);
			// this.getOwnerComponent().setModel(s4SearchHelpModel, "s4SearchHelpModel");

			// var s4ReportDetailModel  = new sap.ui.model.odata.v2.ODataModel(
			// 	"/sap/opu/odata/sap/ZGSPC_ECN_DET_SRV/", {
			// 		json: true,
			// 		maxDataServiceVersion: "4.0",
			// 		loadMetadataAsync: true,
			// 		defaultBindingMode: "OneWay",
			// 		useBatch: true,
			// 		tokenHandling: true,
			// 		defaultCountMode: "None"
			// 	});
			// s4SearchHelpModel.attachMetadataFailed(function (mArgs) {
			// 	// could not interact with S/4
			// 	this.handleMetadataFailure(mArgs);
			// }, this);
			// this.getOwnerComponent().setModel(s4ReportDetailModel, "s4ReportDetailModel");
			
			// var s4ReportHeaderModel = new sap.ui.model.json.JSONModel();
			// this.getOwnerComponent().setModel(s4ReportHeaderModel, "s4ReportHeaderModel");
		},

		handleMetadataFailure: function (mArgs) {
			jQuery.sap.log.error(mArgs.getParameter("message"), ["Status Code: " + mArgs.getParameter("statusCode"),
				"Status Text: " + mArgs.getParameter("statusText"),
				"Component:" + this.getOwnerComponent()
			]);

			sap.m.MessageBox.error(this.getResourceBundle().getText("message.failure.ConnectionError"), {
				title: this.getResourceBundle().getText("message.failure.ConnectionErrorTitle"),
				icon: sap.m.MessageBox.Icon.ERROR,
				actions: [sap.m.MessageBox.Action.OK],
				details: mArgs.getParameter("message") + ". Status Code: " + mArgs.getParameter(
					"statusCode") + ". Status Text: " + mArgs.getParameter("statusText"),
				onClose: function () {
					utilities.exitApp();
				}
			});
		}
	});
});